<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
    xmlns:fo="http://www.w3.org/1999/XSL/Format"
    xmlns:m="http://example.com/manufacturers"
    version="1.0">
  
  <xsl:output method="xml" indent="yes"/>

  <xsl:template match="/">
    <fo:root xmlns:fo="http://www.w3.org/1999/XSL/Format">
      <fo:layout-master-set>
        <fo:simple-page-master master-name="A4" page-height="29.7cm" page-width="21cm" margin="1cm">
          <fo:region-body/>
        </fo:simple-page-master>
      </fo:layout-master-set>
      <fo:page-sequence master-reference="A4">
        <fo:flow flow-name="xsl-region-body">
          <fo:table border-collapse="separate" border-spacing="4pt" width="100%">
            <fo:table-column column-width="3cm"/>
            <fo:table-column column-width="15cm"/>
            <fo:table-header>
              <fo:table-row>
                <fo:table-cell background-color="#D3D3D3" padding="5pt">
                  <fo:block font-family="Arial" font-weight="bold">Название</fo:block>
                </fo:table-cell>
                <fo:table-cell background-color="#D3D3D3" padding="5pt">
                  <fo:block font-family="Arial" font-weight="bold">Описание</fo:block>
                </fo:table-cell>
              </fo:table-row>
            </fo:table-header>
            <fo:table-body>
              <xsl:apply-templates select="m:Manufacturers/m:Manufacturer"/>
            </fo:table-body>
          </fo:table>
        </fo:flow>
      </fo:page-sequence>
    </fo:root>
  </xsl:template>

  <xsl:template match="m:Manufacturer">
    <fo:table-row>
      <fo:table-cell padding="5pt">
        <fo:block font-family="Arial">
          <xsl:value-of select="m:Name"/>
        </fo:block>
      </fo:table-cell>
      <fo:table-cell padding="5pt">
        <fo:block font-family="Arial">
          <xsl:value-of select="m:Description"/>
        </fo:block>
      </fo:table-cell>
    </fo:table-row>
  </xsl:template>
  
</xsl:stylesheet>
